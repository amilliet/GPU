
#ifndef utile_h
#define utile_h

#include <stdio.h>

#include "parameter.h"

void coloring(int y, int x, int move, unsigned ocean[DIM][DIM], c couleurs[DIM][DIM]);
void print_ocean(unsigned ocean[DIM][DIM]);

#endif /* utile_h */
